<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum o psach</title>
    <link rel="stylesheet" href="styl4.css">
</head>
<body>
    <header>
        <h1>Forum wielbicieli psów</h1>
    </header>
    <section class="lewy">
        <img src="obraz.png" alt="foksterier">
    </section>
    <section class="prawy-1">
        <h2>Zapisz się</h2>
        <form action="logowanie.php" method="POST">
            login: <input type="text" name="login"><br>
            hasło: <input type="password" name="haslo"><br>
            powtórz hasło: <input type="password" name="haslo2"><br>
            <button type="submit">Zapisz się</button>
        </form>
        <?php 
        if ($_POST!=NULL) {
        $login=$_POST['login'];
        $haslo=$_POST['haslo'];
        $haslo2=$_POST['haslo2'];
        $status_login="unlogged";
        $conn=mysqli_connect('localhost', 'root', '', 'psy');
        
        if(!empty($login) && !empty($haslo) && !empty($haslo2)){
            $sql="SELECT login FROM `uzytkownicy`;";
            $result=mysqli_query($conn, $sql);
            while($row=mysqli_fetch_assoc($result)){
                if($row['login']==$login){
                    $status_login='failed';
                }  
            }
            if($status_login!='failed'){
                if($haslo==$haslo2){
                    $szyfrowane=sha1($haslo);
                    $sql="INSERT INTO `uzytkownicy` (`id`, `login`, `haslo`) VALUES (NULL, '$login', '$szyfrowane');";
                    mysqli_query($conn, $sql);
                    echo "<p>Konto zostało dodane</p>";
                }
                else {
                    echo "<p>hasła nie są takie same, konto nie zostało dodane</p>";
                }
            }
            else {
                echo "<p>login występuje już w bazie danych, konto nie zostało dodane</p>";
            }   
        }
        else {
            echo '<p>wypełnij wszystkie pola</p>';
        }
        mysqli_close($conn);
    }
        ?>
    </section>
    <section class="prawy-2">
        <h2>Zapraszamy wszystkich</h2>
        <ol>
            <li>właścicieli psów</li>
            <li>weterynarzy</li>
            <li>tych, co chcą kupić psa</li>
            <li>tych, co lubią psy</li>
        </ol>
        <a href="regulamin.html">Przeczytaj regulamin forum</a>
    </section>
    <footer>
        Stronę wykonał: 00000000000
    </footer>
</body>
</html>