<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum o psach</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <header class="baner">
        <h1>Forum miłośników psów</h1>
    </header>
    <section class="lewy">
        <img src="Avatar.png" alt="Użytkownik forum">
        <?php
        $conn=mysqli_connect('localhost','root','','forumpsy');
        $sql="SELECT nick, postow, pytanie FROM konta JOIN pytania on konta.id=pytania.konta_id WHERE pytania.id=1;";
        $result=mysqli_query($conn,$sql);
        while($row=mysqli_fetch_row($result)) {
            echo '<h4>Użytkownik: ' . $row[0] . '</h4>';
            echo '<p>' . $row[1] . ' postów na forum</p>';
            echo '<p>' . $row[2] . '</p>';
        }
        mysqli_close($conn);
        ?>
        <video controls loop playsinline>
            <source src="video.mp4" type="video/mp4">
        </video>
    </section>
    <section class="prawy">
        <form action="index.php" method="post">
            <textarea name="odpowiedz" id="odpowiedz" cols="40" rows="4"></textarea><br>
            <input type="submit" value="Dodaj odpowiedź">
        </form>
        <?php 
        if(!empty($_POST['odpowiedz'])) {
            $conn=mysqli_connect('localhost','root','','forumpsy');
            $odpowiedz=$_POST['odpowiedz'];
            $sql="INSERT INTO `odpowiedzi` (`id`, `Pytania_id`, `konta_id`, `odpowiedz`) VALUES (NULL, '1', '5', '$odpowiedz');";
            $result=mysqli_query($conn,$sql);
            mysqli_close($conn);
        }
        ?>
        <h2>Odpowiedzi na pytanie</h2>
        <ol>
            <?php 
            $conn=mysqli_connect('localhost','root','','forumpsy');
            $sql="SELECT odpowiedzi.id, odpowiedzi.odpowiedz, konta.nick FROM odpowiedzi JOIN konta ON odpowiedzi.konta_id=konta.id WHERE odpowiedzi.Pytania_id=1;";
            $result=mysqli_query($conn,$sql);
            while($row=mysqli_fetch_row($result)) {
                echo '<li>';
                echo $row[1];
                echo '<i><b> ' . $row[2] . '</b></i>';
                echo '<hr>';
                echo '</li>';
            }
            mysqli_close($conn);
            ?>
        </ol>
    </section>
    <footer>
        Autor: 00000000000 <a href="http://mojestrony.pl/" target="blank">Zobacz nasze realizacje</a>
    </footer>
</body>
</html>