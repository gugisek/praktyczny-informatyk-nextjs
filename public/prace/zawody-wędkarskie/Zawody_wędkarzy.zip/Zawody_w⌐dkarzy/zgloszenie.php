<?php
    if(!empty($_POST['lowisko']) && !empty($_POST['data']) && !empty($_POST['sedzia'])){
    $lowisko = $_POST['lowisko'];
    $data = $_POST['data'];
    $sedzia = $_POST['sedzia'];
    $conn = mysqli_connect('localhost', 'root', '', 'wedkarstwo');
    $query = "insert into zawody_wedkarskie (Karty_wedkarskie_id, Lowisko_id, data_zawodow, sedzia) values ('0', '$lowisko', '$data', '$sedzia')";
    mysqli_query($conn, $query);
    mysqli_close($conn);
    header("Location: zawody.html");
    }
    else{header("Location: zawody.html");}
?>