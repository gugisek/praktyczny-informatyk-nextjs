<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organizer</title>
    <link rel="stylesheet" href="styl6.css">
</head>
<body>
    <section class="baner1">
        <h2>MÓJ ORGANIZER</h2>
    </section>
    <section class="baner2">
        <form action="organizer.php" method="POST">
            <label for="wydarzenie">Wpis wydarzenia:</label>
            <input type="text" id="wydarzenie" name="wydarzenie">
            <input type="submit" value="ZAPISZ">
        </form>
        <?php 
        $wydarzenie=$_POST['wydarzenie'];
        $conn=mysqli_connect("localhost","root","","egzamin6");
        $sql="UPDATE zadania SET wpis = '$wydarzenie' where dataZadania='2020-08-27';";
        $result=mysqli_query($conn,$sql);
        ?>
    </section>
    <section class="banner3">
        <img src="logo2.png" alt="Mój organizer">
    </section>
    <section class="glowny">     
        <?php
        $sql="SELECT dataZadania, miesiac, wpis FROM `zadania` where miesiac='sierpien';";
        $result=mysqli_query($conn,$sql);
        while($row=mysqli_fetch_assoc($result)){
            echo "<section class='dzien'>";
            echo "<h6>".$row['dataZadania'].", ".$row['miesiac']."</h6>";
            echo "<p>".$row['wpis']."</p>";
            echo "</section>";
        }
        ?>
    </section>
    <footer>
        <?php 
        $sql="SELECT miesiac, rok FROM `zadania` where dataZadania='2020-08-01';";
        $result=mysqli_query($conn,$sql);
        echo "<h1>miesiąc: ";
        echo mysqli_fetch_assoc($result)['miesiac'];
        echo ", rok: ";
        $result=mysqli_query($conn,$sql);
        echo mysqli_fetch_assoc($result)['rok'];
        echo "</h1>";
        mysqli_close($conn);
        ?>
        <p>Stronę wykonał: 00000000000</p>
    </footer>
</body>
</html>