<!-- Pamiętaj w Visual Studio Code, aby stworzyć ramy dokumentu html wystarczy wpisać na początku tylko ! i kliknąć TAB-->
<!DOCTYPE html>
<html lang="pl">
<head>
    <!-- ustawienie kodowania dla polskich znaków -->
    <meta charset="UTF-8">
    <!-- Tytuł strony -->
    <title>Hurtownia papiernicza</title>
    <!-- Dołączenie pliku css -->
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <!-- Sekcja banner -->
    <section class="banner">
        <!-- Nagłówek o wielkości h1 -->
        <h1>W naszej hurtowni kupisz najtaniej</h1>
    </section>
    <!-- Sekcja z lewa -->
    <section class="lewy">
        <!-- Nagłówek o wielkości h3 -->
        <h3>Ceny wybranych artykułów w hurtowni:</h3>
        <!-- Rzopoczęcie tabeli w której znajduje się skrypt tworzący jej kolumny -->
        <table>
            <?php // rozpoczęcie skryptu php
            $conn = mysqli_connect("localhost", "root", "", "sklep"); // ustanowienie zmiennej $conn, która posłuży do połączenia z bazą danych
            $sql = "SELECT nazwa, cena FROM `towary` limit 4;"; // ustawienie zmiennej $sql, która zawiera zapytanie do bazy danych
            $result = $conn->query($sql); // ustawienie zmiennej $result, która wyśle zapytanie do bazy danych składające się ze zmiennych $conn i $sql
            while ($row = $result->fetch_assoc()) { // pętla while (dopóki), która wyświetla wyniki zapytania do bazy danych jako rząd, wyniki zapytania są zapisywane w zmiennej $row 
                echo "<tr><td>".$row['nazwa']."</td><td>".$row['cena']." zł</td></tr>"; //echo - wyświetl, w tym przypadku wyświetla nazwę i cenę z bazy danych jako elementy tabeli, tr - wiersz tabeli (poziom), td - komórka tabeli
            }
            $conn->close(); // zamknięcie połączenia z bazą danych
            ?>
        </table> <!-- Zakończenie tabeli -->
        
    </section>
    <!-- Sekcja środek -->
    <section class="srodek">
        <!-- Nagłówek o wielkości h3 -->
        <h3>Ile będą kosztować Twoje zakupy?</h3>
        <!-- Formularz, który działa w metodzie post wywołując akcje w pliku index.php (w tym pliku) -->
         <form method="POST" action="index.php">
            <!-- nie trzeba stosować żadnego elementu dla tekstu -->
            wybierz artykuł <select name="wybor"> <!-- select - jest to znacznik listy rozwijanej, name - nazwa listy (ważna, aby skrypt wiedział skąd ma brać dane) -->
                <option value="Zeszyt 60 kartek">Zeszyt 60 kartek</option> <!-- option - jest to element listy rozwijanej, value - wartość, która zostanie wysłana do skryptu po wybraniu jej -->
                <option value="Zeszyt 32 kartki">Zeszyt 32 kartki</option>
                <option value="Cyrkiel">Cyrkiel</option>
                <option value="Linijka 30 cm">Linijka 30 cm</option>
            </select>
            <br> <!-- br - znacznik przejścia do nowej linii -->
            <!-- input - jest to element formularza służący do wprowadzania danych, type - typ elementu (np. text, button, number, submit), name - nazwa elementu (też ważne dla działania póżniejszego skryptu), min - minimalna wartość, max - maksymalna wartość, value - wartość początkowa -->
            liczba sztuk: <input type="number" name="liczba" min = "1"><br> <!--  br - rozpoczęcie od kolejnej linii -->
            <!-- input typu submit jest przyciskiem, który wywołuje akcje zatwierdzania fromularza w którym się znajduje, value w tym przypadku oznacza tekst, który wyświetla się w przycisku -->
            <input type = "submit" value="OBLICZ">
        </form>

        <?php // rozpoczęcie skryptu php
        // ten skrypt używa inaczej zapisywanych poleceń bazy danych, 

        //"$result = mysqli_query($conn,$sql);"      =   "$result = $conn->query($sql);" 
        //"$row = mysqli_fetch_assoc($result);"      =   "$row = $result->fetch_assoc();" 
        //"mysqli_close($conn);"                     =   "$conn->close();"
 
            if(!empty($_POST['wybor']) && !empty($_POST['liczba']) && $_POST['liczba'] >= 1){   // pętla if oznaczająca: jeżeli dane w elemencie "wybor" nie są puste i liczba w elemencie "liczba" nie jest pusta oraz jest większa lub równa 1
                
                // !empty - jeżeli nie jest puste (wykżyknik oznacza przeciwność)
                // $_POST - jest to zmienna globalna, która przechowuje dane wysłane metodą post w nawiasie klamrowym podajemy nazwę elementu formularza z którego chcemy pobrać dane
                // && - oznacza "i"
                // >= - oznacza "większe lub równe"
                // $_POST['wybor'] - w tym przypadku pobieramy dane z elementu formularza o nazwie "wybor"
                // $_POST['liczba'] - w tym przypadku pobieramy dane z elementu formularza o nazwie "liczba"
                // słownie: jeżeli dane w elemencie "wybor" nie są puste i liczba w elemencie "liczba" nie jest pusta oraz jest większa lub równa 1 to wykonaj poniższe instrukcje
                
                $liczba = $_POST['liczba']; // ustawienie zmiennej $liczba, która przechowuje dane z elementu formularza o nazwie "liczba"
                $wybor = $_POST['wybor']; // ustawienie zmiennej $wybor, która przechowuje dane z elementu formularza o nazwie "wybor"

                $conn = mysqli_connect('localhost', 'root', '', 'sklep'); // ustawienie zmiennej $conn, która posłuży do połączenia z bazą danych, w nawiasach podajemy kolejno: adres serwera, nazwa użytkownika, hasło, nazwa bazy danych
                $sql2 = "select cena from towary where nazwa = '$wybor'"; // ustawienie zmiennej $sql2, która przechowuje zapytanie do bazy danych, w tym przypadku pobiera cenę z bazy danych, gdzie nazwa jest równa zmiennej $wybor
                $result = mysqli_query($conn,$sql2); // ustawienie zmiennej $result, która wyśle zapytanie do bazy danych składające się ze zmiennych $conn i $sql2

                while($row = mysqli_fetch_assoc($result)){ // pętla while (dopóki), która wyświetla wyniki zapytania do bazy danych jako rząd, wyniki zapytania są zapisywane w zmiennej $row i wyświetlane dopóki są jakieś wyniki
                    $cena = $row['cena']; // ustawienie zmiennej $cena, która przechowuje dane z kolumny cena z bazy danych

                    $sum = $liczba * $cena; // ustawienie zmiennej $sum, która przechowuje wynik mnożenia zmiennej $liczba i $cena

                    echo 'Cena za ' . $liczba . ' sztuk(i) ' . $wybor . ' wyniesie: ' . $sum . ' zł'; // wyświetlenie tekstu i zmiennych
                }

                mysqli_close($conn); // zamknięcie połączenia z bazą danych
            }
            else{ // jeżeli warunek w pętli if nie jest spełniony to wykonaj poniższe instrukcje
                echo 'Wybierz prawidłowe wartości!'; // wyświetlenie tekstu
            }
        ?> <!--zakończenie skryptu php-->
    </section>
    <!-- sekcja prawy -->
    <section class="prawy">
        <!-- wstawienie obrazu, 
        src - ścieżka gdzie zapisany jest opraz, jeżeli w tym samym folderze co plik .html to można napisać samą nazwę obrazu 
        alt - tekst alternatywny, który wyświetli się jeżeli obraz nie zostanie załadowany -->
        <img src="zakupy2.png" alt="hurtwnia">
        <!-- Nagłówek h3 -->
        <h3>Kontakt</h3>
        <!-- 
        p - paragraf
        br - rozpoczęcie od kolejnej linii
        Tekst wymagający załączenia linku musi być w elemencie a z hiperłączem: href="link", 
        mailto:adresemail - funkcja w linku służąca do przekierowaia do tworzenia e-maila w aplikacji systemowej
        -->
        <p>telefon:<br> 111222333<br> email:<br><a href="mailto:hurt@wp.pl">hurt@wp.pl</a></p>
    </section>
    <!-- znacznik stópki -->
    <footer>
        <!-- Nagłówek h4 -->
        <h4>Witrynę wykonał: 000000000000</h4>
    </footer>
</body>
</html>