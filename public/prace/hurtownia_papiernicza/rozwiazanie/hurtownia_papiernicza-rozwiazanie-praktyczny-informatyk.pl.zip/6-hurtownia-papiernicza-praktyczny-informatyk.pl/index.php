<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hurtownia papiernicza</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <section class="banner">
        <h1>W naszej hurtowni kupisz najtaniej</h1>
    </section>
    <section class="lewy">
        <h3>Ceny wybranych artykułów w hurtowni:</h3>
        <table>
            <?php 
            $conn = mysqli_connect("localhost", "root", "", "sklep");
            $sql = "SELECT nazwa, cena FROM `towary` limit 4;";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>".$row['nazwa']."</td><td>".$row['cena']." zł</td></tr>";
            }
            $conn->close();
            ?>
        </table>
        
    </section>
    <section class="srodek">
        <h3>Ile będą kosztować Twoje zakupy?</h3>
         <form method="POST" action="index.php">
            wybierz artykuł <select name="wybor">
                <option value="Zeszyt 60 kartek">Zeszyt 60 kartek</option>
                <option value="Zeszyt 32 kartki">Zeszyt 32 kartki</option>
                <option value="Cyrkiel">Cyrkiel</option>
                <option value="Linijka 30 cm">Linijka 30 cm</option>
            </select>
            <br>
            liczba sztuk: <input type="number" name="liczba" min = "1"><br>
            <input type = "submit" value="OBLICZ">
        </form>

        <?php

            if(!empty($_POST['wybor']) && !empty($_POST['liczba']) && $_POST['liczba'] >= 1){
                $liczba = $_POST['liczba'];
                $wybor = $_POST['wybor'];

                $conn = mysqli_connect('localhost', 'root', '', 'sklep');
                $sql2 = "select cena from towary where nazwa = '$wybor'";
                $result = mysqli_query($conn,$sql2);

                while($row = mysqli_fetch_assoc($result)){
                    $cena = $row['cena'];

                    $sum = $liczba * $cena;

                    echo 'Cena za ' . $liczba . ' sztuk(i) ' . $wybor . ' wyniesie: ' . $sum . ' zł';
                }

                mysqli_close($conn);
            }
            else{
                echo 'Wybierz prawidłowe wartości!';
            }
        ?>
    </section>
    <section class="prawy">
        <img src="zakupy2.png" alt="hurtwnia">
        <h3>Kontakt</h3>
        <p>telefon:<br> 111222333<br> email:<br><a href="mailto:hurt@wp.pl">hurt@wp.pl</a></p>
    </section>
    <footer>
        <h4>Witrynę wykonał: 000000000000</h4>
    </footer>
</body>
</html>