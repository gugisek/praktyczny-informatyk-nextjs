<!DOCTYPE html>
 <html lang="pl"> <!-- ustawienie języka Polskiego na stronie -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Podróże dalekie i bliskie</title> <!-- Nadanie poprawngo tytułu wyświetlania -->
    <link rel="stylesheet" href="styl6.css"> <!-- Łączenie z arkuszem styli -->
</head>
<body>
    <section class="banner"> <!-- Rozpoczęcie sekcji banera -->
        <h1>Biuro podróży: WESOŁA WYPRAWA</h1> <!-- Nagłówek pierwszego stopnia -->
    </section>
    <section class="ciasteczka"> <!-- Rozpoczęcie sekcji z ciasteczkami -->
        <?php // otwarcie kodu PHP
        //ponieżej pętla if, dosłownie oznacza: jeżeli ciasteczko o nazwie "ciasteczko" nie jest puste to wyświetl: Witaj ponownie [...], w przeciwnym razie wyświetl: Witaj! Nasza [...] oraz ustaw ciasteczko "ciasteczko"
        
        //!empty - jeżeli nie jest puste, ! - oznacza negacje, empty - puste
        //$_COOKIE["nazwa"] - odniesienie się do ciasteczka

        if (!empty($_COOKIE["ciasteczko"])) { //watunek pętli if
            echo "<p>Witaj ponownie na naszej stronie</p>"; // wyświetlanie na stronie
        }   else { // w przeciwnym razie
            echo "<p>Witaj! Nasza strona używa ciasteczek</p>"; // wyświetlanie na stronie
            setcookie("ciasteczko", 1, time() + 3600); // ustawienie ciasteczka: o nazwie "ciasteczko", wartości 1, o czasie wygaśnięcia jednej godziny (3600s). Dokumentacja: https://www.php.net/manual/en/function.setcookie.php
        }

        ?> <!-- zakończenie kodu PHP -->
    </section>
    <section class="lewy"> <!-- Rozpoczęcie sekcji lewej -->
        <table> <!-- Znacznik tabeli -->
            <tr> <!-- Znacznik wiersza - tego w poziomie -->
                <td><img src="polska.jpg" alt="zwiedzanie Krakowa"></td> <!-- Znacznik kolumny -->
                <td><img src="wlochy.jpg" alt="Wenecja i nie tylko"></td>
            </tr>
            <tr><!-- Znacznik wiersza - tego w poziomie -->
                <td><img src="grecja.jpg" alt="gorące Greckie wyspy"></td>
                <td><img src="hiszpania.jpg" alt="Słoneczna Barcelona"></td>
            </tr>
        </table>
    </section>
    <section class="prawy"> <!-- Rozpoczęcie sekcji prawej -->
        <h3>Proponujemy wycieczki</h3> <!-- Nagłówek trzeciego stopnia -->
        <ul> <!-- Znacznik nieuporządkowanej listy -->
            <li> <!-- Element listy -->
                autokarowe
                <ol> <!-- Znacznik uporządkowanej listy -->
                    <li>po Polsce z przewodnikiem</li> <!-- Element listy -->
                    <li>do Niemiec i Czech</li> <!-- Element listy -->
                </ol>
            </li>
            <li> <!-- Element listy -->
                samolotem
                <ol> <!-- Znacznik uporządkowanej listy -->
                    <li>wczasy w Grecji</li> <!-- Element listy -->
                    <li>zwiedzanie Barcelony</li> <!-- Element listy -->
                    <li>zwiedzanie Wenecji</li><!-- Element listy -->
                </ol>
            </li>
        </ul>
        <h3>Pobierz dokumenty</h3> <!-- Nagłówek trzeciego stopnia -->
        <p><a href="regulamin.txt">Regulamin korzystania z usług biura podróży</a></p> <!-- W paragrafie akapit aby link działał i odstęp pomiędzy akapitami był poprawny-->
        
        <a href="http://galeria.pl/" target="_blank">Tu znajdziesz zdjęcia z naszych wycieczek</a> <!-- Akapit z linkiem, target="_blank" - otwiera link w nowej karcie -->
    </section>
    <footer> <!-- Znacznik sekcji stopki -->
        Stronę przygotował 0000000000000
    </footer>

</body>
</html>

<!-- wytłumaczenie aka opracowanie wykonał: gugisek - praktyczny-informatyk.pl -->